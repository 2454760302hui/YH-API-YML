# YH API测试框架项目

## 项目简介
这是一个基于YH API测试框架的完整测试项目。

## 快速开始
1. 安装依赖: pip install -r requirements.txt
2. 配置环境: 修改 config/config.yaml
3. 运行测试: python run.py

## 技术支持
QQ: 2677989813
