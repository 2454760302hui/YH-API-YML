# YH API Testing Framework Project

Complete API testing project template based on YH API Testing Framework, ready to use.

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Demo Project
```bash
python run.py
```

### 3. Configure Your Test Project
Edit `config/config.yaml` file and update it for your API testing configuration:
```yaml
# Change to your API server address
environment:
  base_url: "https://your-api-server.com"
  timeout: 30

# Configure test options
test:
  concurrent: false
  threads: 1
  retry: 3
```

### 4. Add Test Cases
Add your test case files in the `test_cases/api_tests/` directory.

## Project Structure
```
yh-api-test-project/
├── config/                 # Configuration files directory
│   ├── config.yaml        # Main configuration file
│   ├── environments.yaml  # Environment configuration
│   └── global_vars.yaml   # Global variables
├── test_cases/            # Test cases directory
│   └── api_tests/         # API test cases
│       └── login_test.yaml # Login test example
├── data/                  # Test data directory
│   └── test_data.json     # Test data file
├── reports/               # Test reports directory (auto-created)
├── logs/                  # Logs directory (auto-created)
├── run.py                 # Main run script
├── requirements.txt       # Dependencies file
└── README.md             # Project documentation
```

## Advanced Features

### Install Complete YH API Testing Framework
```bash
pip install api-test-yh-pro
```

### Run Tests with YH Framework
```bash
# Run single test file
yh-api-test run test_cases/api_tests/login_test.yaml

# Run all tests
yh-api-test run test_cases/

# Generate Allure report
yh-api-test run test_cases/ --allure --auto-open
```

## Test Case Format

Reference `test_cases/api_tests/login_test.yaml` file:

```yaml
test_suite:
  name: "Login API Tests"
  description: "Test user login related APIs"

test_cases:
  - name: "User Login Success"
    request:
      method: "POST"
      url: "/api/login"
      headers:
        Content-Type: "application/json"
      body:
        username: "test_user"
        password: "test_password"

    assertions:
      - type: "status_code"
        expected: 200
      - type: "json_path"
        path: "$.success"
        expected: true
```

## Custom Configuration

### Environment Configuration
Edit `config/environments.yaml` to configure API addresses for different environments.

### Global Variables
Edit `config/global_vars.yaml` to configure global variables used in tests.

### Test Data
Edit `data/test_data.json` to add test data.

## Technical Support

- QQ: 2677989813
- Project: [YH API Testing Framework](https://github.com/YH-API-Test)

## Usage Tips

1. **First Use**: Run `python run.py` directly to see demo effects
2. **Configure Project**: Modify API address in `config/config.yaml`
3. **Add Tests**: Add YAML test files in `test_cases/api_tests/`
4. **View Results**: Test reports will be generated in `reports/` directory

---
**YH Spirit Lives On! Continuous Improvement, Pursuing Perfection!**
