# YH API测试框架项目

基于YH API测试框架的完整API测试项目模板。

## 🚀 快速开始

### 1. 安装依赖
```bash
pip install api-test-yh-pro
```

### 2. 配置项目
编辑 `config/config.yaml` 文件，更新测试配置。

### 3. 运行测试
```bash
python run.py
```

## 📁 项目结构
```
yh-api-test-project/
├── config/                 # 配置文件目录
│   ├── config.yaml        # 主配置文件
│   ├── environments.yaml  # 环境配置
│   └── global_vars.yaml   # 全局变量
├── test_cases/            # 测试用例目录
│   ├── api_tests/         # API测试用例
│   └── performance_tests/ # 性能测试用例
├── data/                  # 测试数据目录
├── reports/               # 测试报告目录
├── logs/                  # 日志目录
├── scripts/               # 脚本目录
├── run.py                 # 主运行脚本
└── requirements.txt       # 依赖文件
```

## 📞 技术支持
QQ: 2677989813

---
**💪 YH精神永存！持续改进，追求完美！**
