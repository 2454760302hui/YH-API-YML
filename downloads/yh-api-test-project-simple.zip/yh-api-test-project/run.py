#!/usr/bin/env python3
"""
YH API测试框架项目运行脚本
"""

import os
import sys
import yaml
from pathlib import Path
from colorama import init, Fore, Style

# 初始化colorama
init(autoreset=True)

def main():
    """主函数"""
    print(f"{Fore.MAGENTA + Style.BRIGHT}🚀 YH API测试框架{Style.RESET_ALL}")
    print(f"{Fore.CYAN}持续改进，追求完美！{Style.RESET_ALL}")
    
    # 检查配置文件
    config_path = Path("config/config.yaml")
    if not config_path.exists():
        print(f"{Fore.RED}❌ 配置文件不存在: {config_path}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}💡 请先配置 config/config.yaml 文件{Style.RESET_ALL}")
        return
    
    print(f"{Fore.GREEN}✅ 配置文件检查通过{Style.RESET_ALL}")
    
    # 这里可以添加实际的测试执行逻辑
    print(f"{Fore.BLUE}🧪 开始执行测试...{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}💡 请安装 api-test-yh-pro 包后运行完整测试{Style.RESET_ALL}")
    print(f"{Fore.GREEN}📞 技术支持 QQ: 2677989813{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
